
public class ProcessorCompareInfo
{
    
    String left;
    String right;
    String code;
    
}
