import java.util.*;

public class ProcessorSubstituteInfo
{
    List sublistNames = new ArrayList();
    List sublistEntries = new ArrayList();
    
    List substituteKey = new ArrayList();
    List substituteCode = new ArrayList();
    
    List subKeys = new ArrayList();
    List subCodes = new ArrayList();
}
