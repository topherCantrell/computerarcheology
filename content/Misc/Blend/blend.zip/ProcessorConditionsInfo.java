
import java.util.*;

public class ProcessorConditionsInfo
{
    
    boolean leftRequired;
    boolean rightRequired;
    
    List compares = new ArrayList();
    List conditions = new ArrayList();
    
}
