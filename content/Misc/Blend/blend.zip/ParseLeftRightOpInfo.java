/**
 * This class holds parsed strings from two terms separated by an
 * operation.
 */
public class ParseLeftRightOpInfo
{
    String left;     // The string to the left of the operator
    String right;    // The string to the right of the operator
    String operator; // The operator
}
