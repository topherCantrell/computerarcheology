
import java.util.*;

public class ProcessorConditionInfo
{
    
    String symbol;
    
    List codes = new ArrayList();
    
}
